#!/bin/bash
mongod --bind_ip 127.0.0.1